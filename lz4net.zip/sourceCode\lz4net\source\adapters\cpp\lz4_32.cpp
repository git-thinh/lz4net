// This file imports lz4.c prefixing all functions with I32_

#include "lz4_32.h"
#include "..\..\..\original\lz4.c"