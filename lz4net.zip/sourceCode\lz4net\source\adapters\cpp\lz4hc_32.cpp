// This file imports lz4hc.c prefixing all functions with I32_

#include "lz4_32.h"
#include "..\..\..\original\lz4hc.c"