// This file imports lz4hc.c prefixing all functions with I64_

#include "lz4_64.h"
#include "..\..\..\original\lz4hc.c"